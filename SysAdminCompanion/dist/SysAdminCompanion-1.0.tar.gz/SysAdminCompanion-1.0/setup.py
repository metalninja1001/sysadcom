from setuptools import setup

setup(
    name="SysAdminCompanion",
    version="1.0",
    description="A Python script to chat with your Linux system.",
    author="Fahd Abrahams",
    author_email="fahd@perpendicular.web.za",
    packages=["sysadcom"],
)